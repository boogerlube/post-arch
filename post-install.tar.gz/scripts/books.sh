rsync -av --progress --delete root@drwho:/mnt/user/Backup/Calibre/ ~/Books
