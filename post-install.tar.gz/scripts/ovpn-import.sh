for filename in *.ovpn ; do
  nmcli connection import type openvpn file $filename
done
