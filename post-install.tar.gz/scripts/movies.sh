rsync -av --progress --delete  root@pinky:/mnt/user/media/Movies/ /media/bob/Movies/
