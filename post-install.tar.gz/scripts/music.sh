rsync -av --progress --delete  root@pinky:/mnt/user/media/Music/ /media/bob/Music/Music/
