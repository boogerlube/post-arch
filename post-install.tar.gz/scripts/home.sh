rsync -av --progress --delete --exclude '.local/share/Trash/' --exclude '.var' --exclude '.cache' --exclude '.steam' ~/ /media/bob/Sam2TB/bob/
