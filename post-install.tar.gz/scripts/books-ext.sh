rsync -av --progress --delete ~/Books/ /media/bob/Music/Books/
 
