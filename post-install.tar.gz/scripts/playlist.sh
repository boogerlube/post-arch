#!/bin/bash
#
# bash script to create playlist files in music subdirectories
#
# Steve Carlson (stevengcarlson@gmail.com)

find . -type d |
while read subdir
do

 if [[ -f ./"$subdir"/"${subdir##*/}.m3u" ]]
   then
      echo "File  "$subdir"/*.m3u already exists, skipping"
      else
	echo would build for $subdir
	for filename in "$subdir"/*
	do
	if [ ${filename: -4} == ".mp3" ] || [ ${filename: -5} == ".flac" ] || [ ${filename: -5} == ".loss" ] || [ ${filename: -4} == ".m4a" ] || [ ${filename: -4} == ".aif" ]
	then
	echo "${filename##*/}" >> ./"$subdir"/"${subdir##*/}.m3u"
	fi
done
   fi
done