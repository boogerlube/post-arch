rsync -av --progress --delete root@drwho:/mnt/user/Backup/ /media/bob/DrWho/Backup/
rsync -av --progress --delete /media/share/ /media/bob/DrWho/Share/
rsync -av --progress --delete /media/tor/ /media/bob/DrWho/Torrents/ 
