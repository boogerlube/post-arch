rsync -av --progress --delete root@drwho:/mnt/user/Backup/Media/TVArchive/  /media/bob/TVArchive/
