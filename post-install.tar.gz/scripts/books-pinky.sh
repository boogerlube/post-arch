rsync -av --progress --delete ~/Books/ /media/pinky/books/
