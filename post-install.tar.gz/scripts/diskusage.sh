#!/bin/bash

echo Results for: $(hostname):$(pwd)  > ~/du_sorted.txt
sudo nice du -xk --exclude=.snapshot | nice sort -nr | nice \
  awk 'BEGIN {
    split("KB,MB,GB,TB", Units, ",");
  }
  {
    u = 1;
    while ($1 >= 1024) {
      $1 = $1 / 1024;
      u += 1
    }
    $1 = sprintf("%.1f %s", $1, Units[u]);
    print $0;
  }' >> ~/du_sorted.txt