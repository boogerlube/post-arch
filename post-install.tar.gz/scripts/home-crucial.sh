rsync -av --progress --delete --exclude '.local/share/Trash/' --exclude '.var' --exclude '.cache' --exclude '.steam' ~/ /media/bob/Crucial2TB/bob/
