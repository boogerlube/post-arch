rsync -av --progress --delete  root@pinky:/mnt/user/media/Mvid/ /media/bob/Music/Mvid/
